//
//  TestC.swift
//  stGMAT
//
//  Created by sj on 27/02/2018.
//  Copyright © 2018 sj. All rights reserved.
//

import Foundation
class TestC {
    
    init() {

        var ptr: UnsafeMutablePointer<Point> = createPoint()
        print(getPointX(ptr))
        print(getPointY(ptr))
    }
}
