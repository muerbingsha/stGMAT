//
//  ViewController.swift
//  stGMAT
//
//  Created by sj on 25/02/2018.
//  Copyright © 2018 sj. All rights reserved.
//

import UIKit
import Alamofire

class ViewController: UIViewController {

    
    @IBOutlet weak var label: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

 
        var a = PointWrapper()
        print("a.x", a.x, "a.y", a.y);

    

   

        
        
        
        let params: [String: Any] = ["come":"comeContent"]
        let url = URL(string: "http://www.jobyme88.com/iosTest/stGMAT_1.php")
        Alamofire.request(url!, method: .post, parameters: params, encoding: URLEncoding.default, headers: nil).validate().response { (response) in
            let content = String(data: response.data!, encoding: String.Encoding.utf8)
            print("content", content)
        }

        
      
        
        
    
      //  let point: Point = createPoint()
      //  print(point.x, point.y)
        

  
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    


}



