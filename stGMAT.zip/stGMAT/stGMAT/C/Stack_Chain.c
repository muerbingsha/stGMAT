//
//  Stack_Chain.c
//  stGMAT
//
//  Created by sj on 28/02/2018.
//  Copyright © 2018 sj. All rights reserved.
//
// 没有长度限制，不要initStack，但要destroyStack放置内存泄露。

#include "Stack.h"


typedef struct StackNode{
    GameObject value;
    struct StackNode* next;
}Node;

Node* topNode;

bool pushC(GameObject item){
    Node* newNode = malloc(sizeof(Node));
    if (!newNode) {
        printf("not enough space\n");
        return false;
    }
    newNode->value = item;
    newNode->next = topNode;
    topNode = newNode;
    return true;
}

void popC(){
    Node* firstNode = topNode;
    topNode = firstNode->next;
    free(firstNode);
}


bool isEmptyC(){
    if (topNode == NULL) {
        return true;
    } else {
        return false;
    }
}

GameObject getTopItem(){
    if (isEmptyC()){
        return NULL;
    }
    
    return topNode;
}

void destroyStackC(){
    free(topNode);
}

void printAllC(){
    printf("堆栈元素为，从栈顶开始:\n");
    Node* p = topNode;
    while(p!=NULL){
        printf("%d\n",p->value);
        p = p->next;
    }
}

