//
//  Stack_Static_Sequence.c
//  stGMAT
//
//  Created by sj on 28/02/2018.
//  Copyright © 2018 sj. All rights reserved.
//
// 地址静态，长度不可变

#include "Stack.h"




static int top = -1;
static GameObject data[maxsize];


bool isEmpty(){
    if(top == -1){
        return true;
    } else {
        return false;
    }
}

bool isFull(){
    if (top == maxsize - 1){
        return true;
    } else {
        return false;
    }
}

bool push(GameObject item){
    if (isFull()) { return false; }
    data[++top] = item;
    return true;
}

GameObject pop(){
    if (isEmpty()) { return false; }
    return data[top--];
}

void printAll(){
    printf("堆栈元素为，从栈顶开始：\n");
    int i = top ;
    while(i!=-1){
        printf("%d\n", data[i]);
        i--;
    }
}


void changeSize(size){

}

void test(){
    push(1);
    push(4);
    push(6);
    push(8);
    printAll();
    
    pop();
    pop();
    printAll();
}



