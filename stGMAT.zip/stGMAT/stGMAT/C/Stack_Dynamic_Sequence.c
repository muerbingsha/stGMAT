//
//  Stack_Dynamic_Sequence.c
//  stGMAT
//
//  Created by sj on 28/02/2018.
//  Copyright © 2018 sj. All rights reserved.
//
// 地址动态分配，长度可变

#include "Stack.h"




int stackSize;

Stack* initStack(size_t size){
    Stack* s = malloc(sizeof(Stack));
    if (!s) {
        printf("not enough space");
    } else {
        stackSize = size;
        s->top = -1;
    }
    return s;
}

void destroyStack(Stack* s){
    free(s);
}

bool isEmptyDS(Stack* s){
    if (s->top == -1){
        return true;
    } else {
        return false;
    }
}

bool isFullDS(Stack* s){
    if (s->top == stackSize - 1){
        return true;
    } else {
        return false;
    }
}

bool pushDS(Stack* s, GameObject item){
    if (isFullDS(s)) {
        return false;
    }
    
    s->data[++s->top] = item;
    return true;
}

GameObject popDS(Stack* s){
    if (isEmptyDS(s)){
        return NULL;
    }

    return s->data[s->top--];
}

void printAllDS(Stack* s){
    printf("堆栈元素为，从栈顶开始:\n");
    int i = s->top;
    while(i!=-1){
        printf("%d\n", s->data[i]);
        i--;
    }
}

int getLengthDS(Stack* s){
    return s->top + 1;
}






