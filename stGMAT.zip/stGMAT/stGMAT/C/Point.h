//
//  Point.h
//  stGMAT
//
//  Created by sj on 27/02/2018.
//  Copyright © 2018 sj. All rights reserved.
//

#ifndef Point_h
#define Point_h

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>




typedef struct{
    int x;
    int y;
} Point;

Point* createPoint();
void deletePoint(Point* p);
int getPointX(Point* p);
int getPointY(Point* p);
void setPointX(Point* p, int v);
void setPointY(Point* p, int v);

#endif /* Point_h */
