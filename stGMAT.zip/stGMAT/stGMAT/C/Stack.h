//
//  Stack_Static_Sequence.h
//  stGMAT
//
//  Created by sj on 28/02/2018.
//  Copyright © 2018 sj. All rights reserved.
//

#ifndef Stack_h
#define Stack_h

#include <stdio.h>
#include <stdbool.h>
#include <assert.h>
#include <string.h>
#include <stdlib.h>

/* 1 - Static Sequence */
#define maxsize 100
//#define GameObject int
typedef int GameObject;


bool isEmpty();
bool isFull();
bool push(GameObject item);
GameObject pop();
void printAll();
void test();


/* 2 - Dynamic Sequence */
typedef struct{
    GameObject data[maxsize];
    int top;
} Stack;

Stack* initStack(size_t size);
void destroyStack(Stack* s);
bool isEmptyDS(Stack* s);
bool isFullDS(Stack* s);
bool pushDS(Stack* s, GameObject item);
GameObject popDS(Stack* s);
void printAllDS(Stack* s);
int getLengthDS(Stack* s);

/* 3 - Chain */
bool pushC(GameObject item);
void popC();
bool isEmptyC();
GameObject getTopItem();
void destroyStackC();
void printAllC();

#endif /* Stack_h */
