//
//  Point.c
//  stGMAT
//
//  Created by sj on 27/02/2018.
//  Copyright © 2018 sj. All rights reserved.
//

#include "Point.h"


Point* createPoint(){
    Point* p = malloc(sizeof(Point));
    if (p) {
        p->x = 20;
        p->y = 20;
    }
    return p;
}

void deletePoint(Point* p){
    free(p);
}

int getPointX(Point* p){
    return p->x;
}

int getPointY(Point* p){
    return p->y;
}

void setPointX(Point* p, int v){
    p->x = v;
}

void setPointY(Point* p, int v){
    p->y = v;
}
