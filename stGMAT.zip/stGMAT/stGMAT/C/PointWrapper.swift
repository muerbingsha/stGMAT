//
//  PointWrapper.swift
//  stGMAT
//
//  Created by sj on 27/02/2018.
//  Copyright © 2018 sj. All rights reserved.
//

import Foundation


class PointWrapper {
    var _ptr: UnsafeMutablePointer<Point>
    
    init() {
        _ptr = createPoint()
    }
    
    deinit {
        deletePoint(_ptr)
    }
    
    var x: Int {
        get { return Int(getPointY(_ptr)) }
        //it has some problem
        //set { setPointX(_ptr, Int32(newValue))}
    }
    
    var y: Int {
        get { return Int(getPointY(_ptr)) }
    }
    
}



